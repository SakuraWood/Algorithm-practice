from graph import Graph

maps=[[-1,0,0],
[0,-1,0],
[0,0,-1]]
G=Graph(maps)
G.insertNode()
G.insertNode()
G.insertNode()
G.insertNode()
G.insertNode()
G.insertNode()
G.insertNode()
G.insertNode()
G.insertNode()
G.insertNode()
G.insertNode()
G.insertNode()
G.insertNode()
G.insertNode()
G.insertNode()

G.BFSearch()